#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np


# In[11]:


#1.concatinate two numpy arrays column wise and row wise
num1 = np.arange(5,14).reshape(3,3)
num2 = np.arange(20,29).reshape(3,3)
num1
num2
np.concatenate((num1,num2),axis=1)


# In[12]:


#row wise
num1 = np.arange(5,14).reshape(3,3)
num2 = np.arange(20,29).reshape(3,3)
num1
num2


# In[13]:


np.concatenate((num1,num2),axis=0)


# In[7]:


#2.random number generation functions in NumPy generate a set of random numbers using the function rand.
# Generate random integers
a = np.random.randint(10, 20,size=5)
a


# In[21]:


#3.3D array of shape 5x3x2 to contain random decimal numbers between 5 and 10.
arr_1 = np.random.randint(5, 10, size = (5,3,2))
arr_1


# In[15]:


#4.Create a utility function to generate random arrays using def random_array() 
import random 


# In[16]:


def random_array(num):
    rand_num=random.sample(range(1,50),num)
    print(rand_num)
random_array(random.randint(1,10))
    


# In[22]:


#5.create nd compute median using naive method 
#using python
import statistics
arr_2 = [10,20,30,40,50,60]
print("median: %s" %(statistics.median(arr_2)))


# In[49]:


np.median(arr_2)


# In[23]:


#6.create naive function to compute variance function,mean function using python

arr_3 = [12, 15, 11, 22, 19, 64, 16]
v_result = statistics.variance(arr_3)


print(v_result)


# In[24]:


m_result = statistics.mean(arr_3)
print(m_result)


# In[25]:


#7.	Convert a 1D array to a 2D array with 2 rows.
arr_4 = np.array([ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
new_arr= arr_4.reshape(2,5)
print(new_arr)


# In[28]:


#8.	How to stack two arrays vertically? Stack arrays A and B vertically?
a= np.arange(1,7).reshape(2,3)
b= np.arange(8,14).reshape(2,3)
stack_vertical = np.vstack((a,b))
print(stack_vertical)


# In[29]:


#9.	Create a function using numpy to get the common items between two python numpy arrays?
arr_5 = np.array([0, 10, 20, 40, 60])
arr_6 = [10, 30, 40]
print("Common values:")
print(np.intersect1d(arr_5, arr_6))


# In[66]:


#10.Create a python function to get the positions where elements of two arrays match using Numpy function?
x = np.array([0,2,3,4,2,4,3,4,5])
y = np.array([0,1,1,1,3,4,5,5,5])
np.where(x == y)


# In[72]:


#11.How to create a 2D array containing random floats between 5 and 10? 
import random
ran_arr = np.random.uniform(5,10,4).reshape(2,2)
ran_arr


# In[38]:


#12.Extract the text column species from the 1D iris imported using following url np.genfromtxt()
import pandas as pd
iris_df= pd.read_csv("https://raw.githubusercontent.com/ammishra08/MachineLearning/master/Datasets/iris.csv")
display(iris_df)


# In[39]:


np.genfromtxt(iris_df['species'])


# In[ ]:


#13.How to Convert the 1D iris to 2D array iris_2d by omitting the species column and dropping first row?


# In[44]:


#14.How to compute the mean, median, standard deviation of a numpy array on the same iris dataset?
# finding the mean
iris_df= pd.read_csv("https://raw.githubusercontent.com/ammishra08/MachineLearning/master/Datasets/iris.csv")
display(iris_df)


# In[62]:


iris_df.agg(['mean','median','std'])


# In[60]:


#15.How to scale an array so the values range exactly between 0 and 1 using Admission.csv?
admission_df=pd.read_csv("https://raw.githubusercontent.com/ammishra08/MachineLearning/master/Datasets/Admission.csv")
display(admission_df)


# In[61]:


def NormalizeData(data):
    return(data - np.min(data)) / (np.max(data) - np.min(data))
scaled_x = NormalizeData(admission_df)
print(scaled_x)


# In[64]:


#16.Compute and Find the number and position of missing values in iris data’s sepal length column.
## Returns False for missing value & True for not null
iris_df.isnull()


# In[58]:


#17.Drop rows that contain a missing value from a numpy array created by using iris dataset
iris_df.dropna(how = 'any').shape


# In[75]:


#18.Sort the Admission dataset array based on TOEFL Score column and GRE Score. Use separate code for both. 
admission_df['TOEFL Score'].sort_values()


# In[76]:


admission_df['GRE Score'].sort_values()


# In[ ]:


#19.Compute the Euclidean distance between two arrays using Numpy linalg?


# In[3]:


#20.Compute and Find the duplicate entries in the given Numpy array and mark them as True. Create 1-D array 
import numpy as np
arr_7=np.array([2,6,7,8,6,2,1,5,8])
def duplicates(arr_7):
    return[element in arr_7[:i] for i,element in enumerate(arr_7)]
result= duplicates(arr_7)
print(result)


# In[73]:


#21.How to replace all missing values with 0, in a numpy array using Admission.csv and iris.csv?
admission_df.fillna(0)


# In[74]:


iris_df.fillna(0)


# In[ ]:




